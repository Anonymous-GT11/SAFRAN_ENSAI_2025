# Performance Model

MATD project. Aims to construct our own model for turboreactor.

## Getting started

You can install the package using `pip`:

```sh
pip install -e .[all]
```
